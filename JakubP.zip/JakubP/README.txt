1. zaloguj sie do sklepu.

gotowe konto:

Login: Admin
Hasło: Admin

2. wybierz kategorie która cie interesuje wprowadzając ID.

3. wybierając ID przedmiotów, wsadzamy je do koszyka, wychodzimy z kategori wprowadzając wartość 0.

4. jeżeli masz wszystkie przedmioty, wprowadzając 0 przechodzimy do podsumowania koszyka

Wykonał Jakub Piwar