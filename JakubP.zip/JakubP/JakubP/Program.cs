﻿using ConsoleTables;
using JakubP;
using Newtonsoft.Json;
using System.Runtime.CompilerServices;

namespace JakubP
{
    public class Program
    {
        static void Main(string[] args)
        {
            bool login = false;
            string currentPath = Environment.CurrentDirectory;
            string loginFullpath = Path.Combine(currentPath, "Login.json");
            List<AccountModel> WriteLogins = new List<AccountModel>();
            if (!(File.Exists(loginFullpath)) || string.IsNullOrEmpty(File.ReadAllText(loginFullpath)))
            {
                WriteLogins.Add(new AccountModel() { Id = 1, Name = "Admin", Email = "Jakub1709@gmail.com", Password = "Admin" });

                var AccountSerialized = JsonConvert.SerializeObject(WriteLogins);

                File.WriteAllText(loginFullpath, AccountSerialized);
            }


            while (login == false)
            {
                Console.WriteLine("Prosze Wprowadzić login : ");
                string username = Console.ReadLine();

                List<AccountModel> ReadedAccounts = new List<AccountModel>();
                using (var stream = new StreamReader(loginFullpath))
                {
                    string loginJson = stream.ReadToEnd();
                    ReadedAccounts = JsonConvert.DeserializeObject<List<AccountModel>>(loginJson);
                }

                switch (ReadedAccounts.Where(x => x.Name == username).Count())
                {
                    case 0:
                        Console.WriteLine("Użytkownik nie istnieje w bazie danych");
                        break;
                    case 1:
                        Console.WriteLine("Wprowadź hasło: ");
                        string Password = Console.ReadLine();
                        if (ReadedAccounts.Where(x => x.Name == username).FirstOrDefault().Password == Password)
                        {
                            Console.WriteLine("Hasło prawidłowe.");
                            login = true;
                        }
                        else
                        {
                            Console.WriteLine("Hasło nieprawidłowe");
                            login = false;
                        }
                        break;
                    default:
                        Console.WriteLine("coś poszło nie tak...");
                        break;
                }
            }




            string fullpath = Path.Combine(currentPath, "Database.json");
            List<ItemModel> WriteList = new List<ItemModel>();

            if (!(File.Exists(fullpath)) || string.IsNullOrEmpty(File.ReadAllText(fullpath)))
            {
                WriteList.Add(new ItemModel() { Id = 1, Name = "Glock-18", Description = "automatyczny pistolet produkowany przez austriacką firmę Glock.", MainCategory = "Pistolety",  Price = 200 });
                WriteList.Add(new ItemModel() { Id = 2, Name = "P250", Description = "produkowany przez firmę SIG Sauer, popularny wśród policji i wojskowych na całym świecie.", MainCategory = "Pistolety", Price = 300 });
                WriteList.Add(new ItemModel() { Id = 3, Name = "Tec-9", Description = "szwedzko-amerykański pistolet. charakteryzujący się dużą szybkostrzelnością i niestabilnym odrzutem.", MainCategory = "Pistolety",  Price = 500 });
                WriteList.Add(new ItemModel() { Id = 4, Name = "Desert Eagle", Description = "o potężnym kalibrze .50 Action Express, z charakterystycznym wyglądem i imponującą siłą rażenia.", MainCategory = "Pistolety", Price = 700 });
                WriteList.Add(new ItemModel() { Id = 5, Name = "CZ75-Auto", Description = "pistolet samopowtarzalny ", MainCategory = "Pistolety",  Price = 500 });
                WriteList.Add(new ItemModel() { Id = 6, Name = "Rewolwer R8", Description = "amerykański mocny, samopowtarzalny i ciężki pistolet", MainCategory = "Pistolety", Price = 600 });
                WriteList.Add(new ItemModel() { Id = 7, Name = "P2000", Description = "szwajcarsko-niemiecki pistolet", MainCategory = "Pistolety", Price = 200 });
                WriteList.Add(new ItemModel() { Id = 8, Name = "Five-SeveN", Description = "belgijski pistolet", MainCategory = "Pistolety", Price = 500 });
                WriteList.Add(new ItemModel() { Id = 9, Name = "Nova", Description = "charakteryzująca się dużą celnością i mocnym odrzutem", MainCategory = "Strzelby", Price = 1050 });
                WriteList.Add(new ItemModel() { Id = 10, Name = "XM1014", Description = "XM1014 to automatyczna strzelba kalibru 12, zasilana z magazynka bębnowego", MainCategory = "Strzelby", Price = 2000 });
                WriteList.Add(new ItemModel() { Id = 11, Name = "MAG-7", Description = "mała, automatyczna strzelba kalibru 12, zasilana z magazynka rurowego", MainCategory = "Strzelby", Price = 1300 });
                WriteList.Add(new ItemModel() { Id = 12, Name = "Negev", Description = "Negev to izraelski ciężki karabin maszynowy kalibru 5,56 mm lub 7,62 mm", MainCategory = "Karabiny maszynowe", Price = 1700 });
                WriteList.Add(new ItemModel() { Id = 13, Name = "M249", Description = "charakteryzujący się dużą szybkostrzelnością i celnością, ale także dużymi rozmiarami i wagą.", MainCategory = "Karabiny maszynowe", Price = 5200 });
                WriteList.Add(new ItemModel() { Id = 14, Name = "MP9", Description = "szwajcarski pistolet maszynowy", MainCategory = "Pistolety maszynowe", Price = 1250 });
                WriteList.Add(new ItemModel() { Id = 15, Name = "MP7", Description = "niemiecki pistolet maszynowy", MainCategory = "Pistolety maszynowe", Price = 1500 });
                WriteList.Add(new ItemModel() { Id = 16, Name = "UMP-45", Description = "charakteryzujący się dużą mobilnością, niskim odrzutem i dobrymi właściwościami balistycznymi.", MainCategory = "Pistolety maszynowe", Price = 1200 });
                WriteList.Add(new ItemModel() { Id = 17, Name = "PP-Bizon", Description = "charakteryzujący się dużą szybkostrzelnością i stabilnym odrzutem", MainCategory = "Pistolety maszynowe", Price = 1400 });
                WriteList.Add(new ItemModel() { Id = 18, Name = "P90", Description = "belgijski pistolet maszynowy kalibru 5,7 mm, zasilany z magazynka bębnowego o pojemności 50 lub 100 naboi", MainCategory = "Pistolety maszynowe", Price = 2350 });
                WriteList.Add(new ItemModel() { Id = 19, Name = "MAC-10", Description = "amerykański pistolet maszynowy kalibru .45 ACP lub 9 mm, zasilany z magazynka o pojemności 30 lub 32 naboi", MainCategory = "Pistolety maszynowe", Price = 1050 });
                WriteList.Add(new ItemModel() { Id = 20, Name = "Famas", Description = "francuski karabin szturmowy kalibru 5,56 mm, zasilany z magazynka o pojemności 25 naboi", MainCategory = "Karabiny szturmowe", Price = 2050 });
                WriteList.Add(new ItemModel() { Id = 21, Name = "M4A4", Description = "charakteryzujący się wysoką celnością, stabilnym odrzutem i możliwością zamontowania akcesoriów taktycznych.", MainCategory = "Karabiny szturmowe", Price = 3100 });
                WriteList.Add(new ItemModel() { Id = 22, Name = "AUG", Description = " charakteryzujący się charakterystycznym bullpup designem, wysoką celnością, niskim odrzutem", MainCategory = "Karabiny szturmowe", Price = 3300 });
                WriteList.Add(new ItemModel() { Id = 23, Name = "Galil AR", Description = "izraelski karabin szturmowy kalibru 5,56 mm, zasilany z magazynka o pojemności 35 lub 50 naboi", MainCategory = "Karabiny szturmowe", Price = 1800 });
                WriteList.Add(new ItemModel() { Id = 24, Name = "AK-47", Description = "charakteryzujący się dużą niezawodnością, prostotą konstrukcji i mocnym odrzutem", MainCategory = "Karabiny szturmowe", Price = 2700 });
                WriteList.Add(new ItemModel() { Id = 25, Name = "SG 553", Description = "szwajcarski karabin szturmowy", MainCategory = "Karabiny szturmowe", Price = 3000 });
                WriteList.Add(new ItemModel() { Id = 26, Name = "SSG 08", Description = "jest popularny w sportach strzeleckich i bardzo popularnym karabinem snajperskim na świecie.", MainCategory = "Karabiny snajperskie", Price = 1700 });
                WriteList.Add(new ItemModel() { Id = 27, Name = "AWP", Description = "jest stosowany głównie do precyzyjnych i celowanych strzałów na dalsze dystanse.", MainCategory = "Karabiny snajperskie", Price = 4750 });
                WriteList.Add(new ItemModel() { Id = 28, Name = "G3SG1", Description = "niemiecki karabin snajperski kalibru 7,62 mm", MainCategory = "Karabiny snajperskie", Price = 5000 });
                WriteList.Add(new ItemModel() { Id = 29, Name = "SCAR-20", Description = "belgijsko-amerykański karabin snajperski", MainCategory = "Karabiny snajperskie", Price = 5000 });
                WriteList.Add(new ItemModel() { Id = 30, Name = "Granat błyskowo-hukowy", Description = "po wystrzeleniu emituje silny huk i jaskrawe błyski światła", MainCategory = "Granaty", Price = 200 });
                WriteList.Add(new ItemModel() { Id = 31, Name = "Granat dymny", Description = "po wystrzeleniu emituje gęsty dym, mający na celu zaciemnienie terenu i utrudnienie widoczności", MainCategory = "Granaty", Price = 300 });
                WriteList.Add(new ItemModel() { Id = 32, Name = "Granat zaczepny", Description = "wystrzeleniu przykleja się do celu za pomocą specjalnej łapy lub haczyka, a następnie detonuje", MainCategory = "Granaty", Price = 300 });



                var serialized = JsonConvert.SerializeObject(WriteList);

                File.WriteAllText(fullpath, serialized);
            }

            List<ItemModel> ReadedItems = new List<ItemModel>();

            using (var stream = new StreamReader(fullpath))
            {
                string json = stream.ReadToEnd();
                ReadedItems = JsonConvert.DeserializeObject<List<ItemModel>>(json);
            }


            var table = new ConsoleTable("ID","Kategoria");

            table.Configure(c => c.EnableCount = false);

            List<CategoriesModel> categoriesList = GetCategoriesTable(ReadedItems);
            
            foreach(var category in categoriesList)
            {
                table.AddRow(category.CategoryId, category.CategoryName);
            }


            table.Write();


            bool exit = false;
            var itemsTable = new ConsoleTable("ID", "Nazwa", "Cena");
            List<ItemModelDto> items = new List<ItemModelDto>();
            int LastestId = 1;
            while (exit == false)
            {
                if(LastestId == 0)
                {
                    table.Columns.Clear();
                    table.Rows.Clear();
                    table.Columns.Add("ID");
                    table.Columns.Add("Kategoria");
                    foreach (var category in categoriesList)
                    {
                        table.AddRow(category.CategoryId, category.CategoryName);
                    }

                    table.Write();
                }


                table.Columns.Clear();
                table.Rows.Clear();

                if(items.Count != 0) 
                {
                Console.WriteLine( $"Posiadasz {items.Count.ToString()} przedmiotów w swoim koszyku. Jeśli chcesz zobaczyć koszyk, wprowadź: 0.");
                }

                Console.WriteLine("wprowadź ID kategori lub wprowadź: 9999 by wyjść");
                string id = Console.ReadLine();

                if(!(int.TryParse(id, out int okId))) 
                {
                    Console.WriteLine("Użyj tylko cyfr!");
                    continue;
                }

                if(okId == 9999)
                {
                    exit= true;
                    break;
                }

                else if(okId == 0)
                {
                    itemsTable.Rows.Clear();

                    foreach(var item in items)
                    {
                        itemsTable.AddRow(item.Id,item.Name, item.Price);
                    }

                    itemsTable.Configure(c => c.EnableCount = false);

                    itemsTable.Write();
                    Console.WriteLine($"Posiadasz {items.Count} przedmiotów w koszyku o wartości {items.Sum(x=> x.Price)}");
                    Console.ReadKey();
                    continue;
                }


                string selectedCategory = string.Empty;
                if (okId <= categoriesList.Count) { 
                    selectedCategory = categoriesList.Where(x => x.CategoryId == okId).FirstOrDefault().CategoryName;
                }
                else
                {
                    if(okId != 0)
                    {
                        okId = LastestId;
                        Console.WriteLine("ta kategoria nie istnieje");
                        continue;
                    }
                }
                table.Columns.Add("ID");
                table.Columns.Add("Nazwa");
                table.Columns.Add("Opis");
                table.Columns.Add("Cena");

                foreach (var item in ReadedItems)
                {
                    if (item.MainCategory == selectedCategory)
                    {
                        table.AddRow(item.Id, item.Name, item.Description, item.Price);
                    }
                }

                table.Write();

                bool exitBasket = false;
                while (exitBasket == false)
                {
                    Console.WriteLine("jesteś w trybie dodawania do koszyka, aby wyjść wprowadź: 0");
                    Console.WriteLine("Dodaj przedmiot do koszyka wprowadzając jego ID: ");
                    string itemId = Console.ReadLine();

                    if(!(int.TryParse(itemId, out int resultId)))
                    {
                        Console.WriteLine("Użyj tylko cyfr!");
                        continue;
                    }

                    if (resultId == 0) 
                    { 
                        exitBasket = true;
                        continue;
                    }

                    resultId--;

                    if (resultId <= ReadedItems.Count-1)
                    {
                        ItemModelDto itemModel = new ItemModelDto() { Id = ReadedItems[resultId].Id, Name = ReadedItems[resultId].Name, Price = ReadedItems[resultId].Price };

                        items.Add(itemModel);
                    }
                    else
                    {
                        Console.WriteLine("Taki produkt nie istnieje!");
                    }

                }

                if(exitBasket == false)
                {
                    LastestId = okId;
                    continue;
                }
                LastestId = 0;
            }

            Console.ReadKey();
        }


        public static List<CategoriesModel> GetCategoriesTable(List<ItemModel> ReadedItems)
        {

            List<CategoriesModel> categoriesList = new List<CategoriesModel>();
            int actualId = 1;

            for (int i = 0; i < ReadedItems.Count - 1; i++)
            {
                if (categoriesList.Where(x => x.CategoryName == ReadedItems[i].MainCategory).Count() == 0)
                {
                    categoriesList.Add(new CategoriesModel() { CategoryId = actualId, CategoryName = ReadedItems[i].MainCategory });
                    actualId++;
                }
            }

            return categoriesList;
        }

    }


}

